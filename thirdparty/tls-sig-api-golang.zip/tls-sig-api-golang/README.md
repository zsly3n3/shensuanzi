# tls-sig-api-golang

only support P224/P256/P384/P521 curves