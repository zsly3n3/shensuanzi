package important

const IM_SDK_APPID = 1400185580
