package important

const OSSEndpoint = "oss-cn-shenzhen.aliyuncs.com"
const OSSAccessKeyId = "LTAIrI5VLxul4WVs"
const OSSAccessKeySecret = "90tKumbwoLaRJID8rRdTcwSPfCAAlS"
const OSSBucketName = "shensuanzi"
